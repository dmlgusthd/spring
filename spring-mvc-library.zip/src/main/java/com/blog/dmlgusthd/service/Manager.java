package com.blog.dmlgusthd.service;

public class Manager {
	private String mId;
	private String mPw;
	
	public String getmId() {
		return mId;
	}
	public void setmId(String mId) {
		this.mId = mId;
	}
	public String getmPw() {
		return mPw;
	}
	public void setmPw(String mPw) {
		this.mPw = mPw;
	}
	public static Manager findByUserIdAndPassword(String getmId, String getmPw) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
